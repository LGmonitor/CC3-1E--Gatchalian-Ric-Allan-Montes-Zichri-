
package rpg;


public class RPG {

   
    public static void main(String[] args) {
        
        TestCharacter RPG = new TestCharacter();
    }
    
}
